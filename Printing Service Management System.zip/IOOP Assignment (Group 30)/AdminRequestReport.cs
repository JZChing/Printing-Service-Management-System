﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace IOOP_Assignment1
{
    public partial class AdminRequestReport : Form
    {
        
        public AdminRequestReport() 
        {
            InitializeComponent();
            

        }

        private void RequestReport_Load(object sender, EventArgs e)
        {
            

        }

        private void dgvRequest_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cbMonth_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnGenerateRequest_Click(object sender, EventArgs e)
        {
            
            if (cbMonth.SelectedItem != null && cbYear.SelectedItem != null) //to make sure month and year is selected for monthly report
            {
                Request request = new Request();
                request.GenerateRequestReport(cbMonth.SelectedItem.ToString(), cbYear.SelectedItem.ToString(), dgvRequest);
                request.LoadRequestSummary(cbMonth.SelectedItem.ToString(), cbYear.SelectedItem.ToString(), lblNumOfReq, lblServ0001, lblServ0002, lblServ0003, lblServ0004, lblServ0005, lblServ0006);
            }
            else
            {
                MessageBox.Show("Please choose the month and year.");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
