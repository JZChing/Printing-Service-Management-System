﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment1
{
    public partial class RequestHistoryForm : Form
    {
        public RequestHistoryForm(string userID)
        {
            InitializeComponent();
            Request request = new Request();
            request.GetRequestHistory(userID, RequestHistoryTable);//Retreive Data And Display It
        }

        private void RequestHistory_Load(object sender, EventArgs e)
        {
        }
    }
}
