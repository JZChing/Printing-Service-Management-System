﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace IOOP_Assignment1
{
    public partial class LogoutConfirmationForm : Form
    {
        
        public LogoutConfirmationForm()
        {
            InitializeComponent();
            
        }

        private void LoginConfirmation_Load(object sender, EventArgs e)
        {

        }

        private void btnYes_Click(object sender, EventArgs e)
        {


            List<Form> formsToClose = new List<Form>();
            foreach (Form form in Application.OpenForms)
            {

                if (form.Name != "LoginPage")
                {
                    formsToClose.Add(form);
                }
            }

            foreach (Form formToClose in formsToClose)
            {
                formToClose.Close();
            }



        }

        
    }
}
