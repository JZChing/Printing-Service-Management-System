﻿namespace IOOP_Assignment1
{
    partial class AdminPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRegNewUser = new System.Windows.Forms.Button();
            this.btnRequestReport = new System.Windows.Forms.Button();
            this.btnViewTotalIncome = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnViewProfile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnRegNewUser
            // 
            this.btnRegNewUser.Location = new System.Drawing.Point(101, 99);
            this.btnRegNewUser.Name = "btnRegNewUser";
            this.btnRegNewUser.Size = new System.Drawing.Size(225, 50);
            this.btnRegNewUser.TabIndex = 0;
            this.btnRegNewUser.Text = "Register New User";
            this.btnRegNewUser.UseVisualStyleBackColor = true;
            this.btnRegNewUser.Click += new System.EventHandler(this.btnRegNewUser_Click);
            // 
            // btnRequestReport
            // 
            this.btnRequestReport.Location = new System.Drawing.Point(101, 223);
            this.btnRequestReport.Name = "btnRequestReport";
            this.btnRequestReport.Size = new System.Drawing.Size(225, 50);
            this.btnRequestReport.TabIndex = 1;
            this.btnRequestReport.Text = "View and generate request report";
            this.btnRequestReport.UseVisualStyleBackColor = true;
            this.btnRequestReport.Click += new System.EventHandler(this.btnRequestReport_Click);
            // 
            // btnViewTotalIncome
            // 
            this.btnViewTotalIncome.Location = new System.Drawing.Point(447, 99);
            this.btnViewTotalIncome.Name = "btnViewTotalIncome";
            this.btnViewTotalIncome.Size = new System.Drawing.Size(225, 50);
            this.btnViewTotalIncome.TabIndex = 2;
            this.btnViewTotalIncome.Text = "View and generate total income report";
            this.btnViewTotalIncome.UseVisualStyleBackColor = true;
            this.btnViewTotalIncome.Click += new System.EventHandler(this.btnViewTotalIncome_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(300, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Welcome Admin!";
            // 
            // btnLogOut
            // 
            this.btnLogOut.Location = new System.Drawing.Point(280, 342);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(225, 50);
            this.btnLogOut.TabIndex = 4;
            this.btnLogOut.Text = "Log out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnViewProfile
            // 
            this.btnViewProfile.Location = new System.Drawing.Point(447, 223);
            this.btnViewProfile.Name = "btnViewProfile";
            this.btnViewProfile.Size = new System.Drawing.Size(225, 50);
            this.btnViewProfile.TabIndex = 5;
            this.btnViewProfile.Text = "Update Profile";
            this.btnViewProfile.UseVisualStyleBackColor = true;
            this.btnViewProfile.Click += new System.EventHandler(this.btnViewProfile_Click);
            // 
            // AdminPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnViewProfile);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnViewTotalIncome);
            this.Controls.Add(this.btnRequestReport);
            this.Controls.Add(this.btnRegNewUser);
            this.Name = "AdminPage";
            this.Text = "AdminPage";
            this.Load += new System.EventHandler(this.AdminPage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRegNewUser;
        private System.Windows.Forms.Button btnRequestReport;
        private System.Windows.Forms.Button btnViewTotalIncome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnViewProfile;
    }
}

