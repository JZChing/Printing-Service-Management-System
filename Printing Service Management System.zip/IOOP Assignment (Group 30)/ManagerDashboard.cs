﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment1
{
    public partial class ManagerDashboardForm : Form
    {
        private string userID;
        private User user = new User();
        public ManagerDashboardForm(string userID)
        {
            InitializeComponent();
            this.userID = userID;
            user.GetUserData(userID);
        }

        private void btnCheckStatus_Click(object sender, EventArgs e)
        {
            
            RequestStatusForm rsf = new RequestStatusForm();
            rsf.ShowDialog();
        }   
        
        private void ManagerDashboardForm_Load(object sender, EventArgs e)
        {

        }

        private void btnAcceptPayment_Click_1(object sender, EventArgs e)
        {
            AcceptPaymentForm apf = new AcceptPaymentForm();
            apf.ShowDialog();
        }

        private void btnAssignRequest_Click_1(object sender, EventArgs e)
        {
            AssignRequestForm arf = new AssignRequestForm();
            arf.ShowDialog();
        }

        private void btnLogout_Click_1(object sender, EventArgs e)
        {
            LogoutConfirmationForm lcf = new LogoutConfirmationForm();
            lcf.ShowDialog();
        }

        private void btnUpdateProfile_Click_1(object sender, EventArgs e)
        {
            ProfileForm pf = new ProfileForm(user,userID);
            pf.ShowDialog();
        }
    }
}
