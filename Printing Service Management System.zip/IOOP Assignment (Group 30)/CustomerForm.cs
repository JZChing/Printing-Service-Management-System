﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment1
{
    public partial class CustomerForm : Form
    {
        private string userID;
        private User user = new User();

        public CustomerForm(string userID)
        {
            
            InitializeComponent();
            this.userID = userID;
            
            try
            {
                
                //Retrieving User Data To Display While Opening The Form
                user.GetUserData(userID);//Retrieve User Data Using Method Created In Class
                
                
                //Display User Data(Password Not Displayed)
                lblCustomerID2.Text = ": " + userID;
                lblName2.Text = ": " + user.Name;
                lblEmail2.Text = ": " + user.Email;
                lblContact2.Text = ": " + user.Contact;
                
            }
            catch
            {
                MessageBox.Show("Error: Unable To Display User Info ");
            }
            


        }



        private void CustomerForm_Load(object sender, EventArgs e)
        {          


        }



        private void btnRequest_Click(object sender, EventArgs e)
        {
            //Opens Request Form,userID passed So that Request Form Can Use It To Retrieve Data Required          
            RequestForm rf = new RequestForm(userID);
            rf.ShowDialog();
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            //Opens History Form,userID passed So that Request Form Can Use It To Retrieve Data Required
            RequestHistoryForm hf = new RequestHistoryForm(userID);
            hf.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //Closes The Current Form
            LogoutConfirmationForm lcf = new LogoutConfirmationForm();
            lcf.ShowDialog();
        }

        private void btnProfileUpdate_Click(object sender, EventArgs e)
        {
            //Opens Profile Form,userID passed So that Request Form Can Use It To Retrieve Data Required
            ProfileForm pf = new ProfileForm(user,userID);
            pf.ShowDialog();
        }

        private void lblName2_Click(object sender, EventArgs e)
        {

        }
    }
}
