﻿namespace IOOP_Assignment1
{
    partial class StatusForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lblRequestID = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.STComboBox = new System.Windows.Forms.ComboBox();
            this.txtRequestID = new System.Windows.Forms.TextBox();
            this.requestBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dgvReq = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.requestBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReq)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(615, 252);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(145, 70);
            this.btnUpdate.TabIndex = 1;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lblRequestID
            // 
            this.lblRequestID.AutoSize = true;
            this.lblRequestID.Location = new System.Drawing.Point(364, 268);
            this.lblRequestID.Name = "lblRequestID";
            this.lblRequestID.Size = new System.Drawing.Size(71, 16);
            this.lblRequestID.TabIndex = 2;
            this.lblRequestID.Text = "RequestID";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(364, 331);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(44, 16);
            this.lblStatus.TabIndex = 5;
            this.lblStatus.Text = "Status";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Check New Request";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(615, 328);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(145, 58);
            this.button1.TabIndex = 7;
            this.button1.Text = "Back to dashboard";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // STComboBox
            // 
            this.STComboBox.FormattingEnabled = true;
            this.STComboBox.Items.AddRange(new object[] {
            "Pending",
            "Completed"});
            this.STComboBox.Location = new System.Drawing.Point(457, 328);
            this.STComboBox.Name = "STComboBox";
            this.STComboBox.Size = new System.Drawing.Size(104, 24);
            this.STComboBox.TabIndex = 8;
            this.STComboBox.SelectedIndexChanged += new System.EventHandler(this.STComboBox_SelectedIndexChanged);
            // 
            // txtRequestID
            // 
            this.txtRequestID.Location = new System.Drawing.Point(457, 262);
            this.txtRequestID.Name = "txtRequestID";
            this.txtRequestID.Size = new System.Drawing.Size(100, 22);
            this.txtRequestID.TabIndex = 9;
            // 
            // dgvReq
            // 
            this.dgvReq.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReq.Location = new System.Drawing.Point(21, 28);
            this.dgvReq.Name = "dgvReq";
            this.dgvReq.RowHeadersWidth = 51;
            this.dgvReq.RowTemplate.Height = 24;
            this.dgvReq.Size = new System.Drawing.Size(1130, 203);
            this.dgvReq.TabIndex = 10;
            this.dgvReq.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReq_CellContentClick);
            // 
            // StatusForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1180, 450);
            this.Controls.Add(this.dgvReq);
            this.Controls.Add(this.txtRequestID);
            this.Controls.Add(this.STComboBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblRequestID);
            this.Controls.Add(this.btnUpdate);
            this.Name = "StatusForm";
            this.Text = "Update Request";
            this.Load += new System.EventHandler(this.StatusForm_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.requestBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReq)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label lblRequestID;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox STComboBox;
        private System.Windows.Forms.TextBox txtRequestID;
        
        private System.Windows.Forms.BindingSource requestBindingSource;
        
        private System.Windows.Forms.DataGridView dgvReq;
    }
}

