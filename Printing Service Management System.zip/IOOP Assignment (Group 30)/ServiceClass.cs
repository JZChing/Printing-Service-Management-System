﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment1
{
    public class Service
    {
        private string _ServiceID;
        private string _ServiceType;
        private decimal _ServiceFees;
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-GFKO02HO ;Initial Catalog=IOOPAssignment;Integrated Security=True");

        public Service(string ID, string Type, decimal Fee)
        {
            _ServiceID = ID;
            _ServiceType = Type;
            _ServiceFees = Fee;
        }
        public Service()
        {

        }


        public string ID
        {
            get { return _ServiceID; }
            set { _ServiceID = value; }
        }

        public string Type
        {
            get { return _ServiceType; }
            set { _ServiceType = value; }
        }

        public decimal Fees
        {
            get { return _ServiceFees; }
            set { _ServiceFees = value; }
        }

        public void GetDetails(int rowNum, RadioButton RbUrgentYes, int quantity, Label lblTotalCost2)
        {
            try
            {
                            
                //To Get Selected Service Data From SQL

                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT ServiceID, Service_Type, Fees FROM ServiceList", con);      //Selecting Data From SQL Table
                SqlDataAdapter sda = new SqlDataAdapter(cmd);               //Taking Data Based on cmd 
                DataTable dt = new DataTable("ServiceInfo");                //New Table Containing Taken Data
                sda.Fill(dt);


                ID = dt.Rows[rowNum].Field<string>("ServiceID");
                Type = dt.Rows[rowNum].Field<string>("Service_Type");
                Fees = decimal.Parse(dt.Rows[rowNum].Field<string>("Fees"));

                Fees = Fees * quantity;



                if (RbUrgentYes.Checked) //Surcharge Calculation
                {

                    decimal surcharge = Fees * 3 / 10;
                    Fees = Fees + surcharge;
                }


                lblTotalCost2.Text = Fees.ToString();
                con.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
            }
        }

        public bool ValidationInputQuantity(TextBox txtQuantity)
        {
            try
            //This Comes Under New Request
            //To Validate User Entered Proper Quantity
            {
                int.TryParse(txtQuantity.Text, out int _quantity);
                if (_quantity < 1)
                {
                    MessageBox.Show("Please Enter An Integer Number Greater Than 0");
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch
            {
                MessageBox.Show("Please Enter A Integer Value For Quantity");
                txtQuantity.Focus();
                return false;
            }


        }


        public void TotalCostDisplay(TextBox txtQuantity, RadioButton RbUrgentYes, Label lblTotalCost2, List<RadioButton> RbList)
        {
            //This Comes Under New Request
            //User Is Able To See Total Cost
            if (!int.TryParse(txtQuantity.Text, out int quantity))
            {
                return;
            }
            int rowNum = RowSelection(RbList);
            GetDetails(rowNum, RbUrgentYes, int.Parse(txtQuantity.Text), lblTotalCost2);
        }

        public int RowSelection(List<RadioButton> radioButtons)
        {
            // Iterate through the list of RadioButtons
            for (int i = 0; i < radioButtons.Count; i++)
            {

                if (radioButtons[i].Checked)
                {

                    return i;//Return Selected Index
                }
            }


            MessageBox.Show("Please Select From Service Options Given");
            return -1;//-1 Means No Selection
        }



    }
}
