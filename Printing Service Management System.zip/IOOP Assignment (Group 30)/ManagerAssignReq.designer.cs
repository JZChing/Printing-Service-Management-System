﻿namespace IOOP_Assignment1
{
    partial class AssignRequestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbWorker = new System.Windows.Forms.ComboBox();
            this.lblWorker = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnAssignRequest = new System.Windows.Forms.Button();
            this.lblAssignChoiceList = new System.Windows.Forms.Label();
            this.cbRequestID = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvNewRequest = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNewRequest)).BeginInit();
            this.SuspendLayout();
            // 
            // cbWorker
            // 
            this.cbWorker.FormattingEnabled = true;
            this.cbWorker.Location = new System.Drawing.Point(485, 258);
            this.cbWorker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbWorker.Name = "cbWorker";
            this.cbWorker.Size = new System.Drawing.Size(142, 24);
            this.cbWorker.TabIndex = 12;
            // 
            // lblWorker
            // 
            this.lblWorker.AutoSize = true;
            this.lblWorker.Location = new System.Drawing.Point(410, 261);
            this.lblWorker.Name = "lblWorker";
            this.lblWorker.Size = new System.Drawing.Size(57, 16);
            this.lblWorker.TabIndex = 11;
            this.lblWorker.Text = "Worker: ";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(510, 305);
            this.btnExit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(117, 30);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnAssignRequest
            // 
            this.btnAssignRequest.Location = new System.Drawing.Point(43, 300);
            this.btnAssignRequest.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAssignRequest.Name = "btnAssignRequest";
            this.btnAssignRequest.Size = new System.Drawing.Size(159, 30);
            this.btnAssignRequest.TabIndex = 9;
            this.btnAssignRequest.Text = "Assign Request";
            this.btnAssignRequest.UseVisualStyleBackColor = true;
            this.btnAssignRequest.Click += new System.EventHandler(this.btnAssignRequest_Click);
            // 
            // lblAssignChoiceList
            // 
            this.lblAssignChoiceList.AutoSize = true;
            this.lblAssignChoiceList.Location = new System.Drawing.Point(47, 32);
            this.lblAssignChoiceList.Name = "lblAssignChoiceList";
            this.lblAssignChoiceList.Size = new System.Drawing.Size(116, 16);
            this.lblAssignChoiceList.TabIndex = 8;
            this.lblAssignChoiceList.Text = "Assign Choice List";
            // 
            // cbRequestID
            // 
            this.cbRequestID.FormattingEnabled = true;
            this.cbRequestID.Location = new System.Drawing.Point(138, 258);
            this.cbRequestID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbRequestID.Name = "cbRequestID";
            this.cbRequestID.Size = new System.Drawing.Size(142, 24);
            this.cbRequestID.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 261);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "RequestID: ";
            // 
            // dgvNewRequest
            // 
            this.dgvNewRequest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNewRequest.Location = new System.Drawing.Point(43, 67);
            this.dgvNewRequest.Name = "dgvNewRequest";
            this.dgvNewRequest.RowHeadersWidth = 51;
            this.dgvNewRequest.RowTemplate.Height = 24;
            this.dgvNewRequest.Size = new System.Drawing.Size(584, 167);
            this.dgvNewRequest.TabIndex = 15;
            // 
            // AssignRequestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.dgvNewRequest);
            this.Controls.Add(this.cbRequestID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbWorker);
            this.Controls.Add(this.lblWorker);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAssignRequest);
            this.Controls.Add(this.lblAssignChoiceList);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AssignRequestForm";
            this.Text = "Assign Request Form";
            this.Load += new System.EventHandler(this.AssignRequestForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNewRequest)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbWorker;
        private System.Windows.Forms.Label lblWorker;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnAssignRequest;
        private System.Windows.Forms.Label lblAssignChoiceList;
        private System.Windows.Forms.ComboBox cbRequestID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvNewRequest;
    }
}