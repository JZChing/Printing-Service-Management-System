﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;

namespace IOOP_Assignment1
{
    public partial class ProfileForm : Form
    {
        User user;     
        bool dataChange = false;
        private string user_id;
        public ProfileForm(User user, string userid)
        {
            user_id = userid;
            InitializeComponent();
            this.user = user;
            
            //Display Info(Password Not Displayed)
            lblRole2.Text = ": " + user.Role;
            lblUserID2.Text = ": " + userid;
            lblName2.Text = ": " + user.Name;            
            txtEmail.Text = user.Email;
            txtContact.Text = user.Contact;
            
            btnSaveChanges.Enabled = false;//Only Enabled If Any Changes Made
        }

        private void Profile_Load(object sender, EventArgs e)
        {


        }



        private void btnSaveChanges_Click(object sender, EventArgs e)
        {

            //Updating Data- 3 Parts(Validating User Input,Confirmation,Updating The SQL Table)
            //Part 2 And 3 In Update Confirm Form



            //Part1- Validatng User Input
            if (user.ValidateProfileUserInput(dataChange,txtPassword1,txtPassword2,txtContact,txtEmail) == true)
            {
                UpdateConfirmForm ucf = new UpdateConfirmForm(user,user_id);//Get User Confirmation
                ucf.ShowDialog();
            }
            else
            {
                return;
            }
        }


        //To Enable btnSaveChanges If Changes Are Made
        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            btnSaveChanges.Enabled = true;
        }

        private void txtContact_TextChanged(object sender, EventArgs e)
        {
            btnSaveChanges.Enabled = true;
        }

        private void txtPassword2_TextChanged(object sender, EventArgs e)
        {
            btnSaveChanges.Enabled = true;
            dataChange = true;
        }
        private void txtPassword1_TextChanged(object sender, EventArgs e)
        {
            dataChange = true;
            btnSaveChanges.Enabled = true;
        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            //Close The Form
            this.Close();
        }

        private void txtPassword1_Click(object sender, EventArgs e)
        {
            txtPassword1.Text = "";
        }
        private void txtPassword2_Click(object sender, EventArgs e)
        {
            txtPassword2.Text = "";
        }

        private void lblCustomerID2_Click(object sender, EventArgs e)
        {

        }

        private void lblCustomerID_Click(object sender, EventArgs e)
        {

        }
    }
}

