﻿using IOOP_Assignment1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment1
{
    public partial class AcceptPaymentForm : Form
    {
        public AcceptPaymentForm()
        {
            InitializeComponent();

            Request request = new Request();
            request.LoadRequestToPay(dgvRequest);

            int requestid;
            SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-GFKO02HO;Initial Catalog=IOOPAssignment;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT RequestID FROM Request Where Payment_Status = 0", con);
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {                  
                    requestid = reader.GetInt32(0);
                    cbRequestID.Items.Add(requestid);
                }
            }
            con.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGenerateReceipt_Click(object sender, EventArgs e)
        {
            string SelectedID = cbRequestID.SelectedItem.ToString();
            int SelectedID1 = int.Parse(SelectedID);
            try
            {
                
                ReceiptForm rf = new ReceiptForm(SelectedID1);
                rf.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAcceptPayment_Click(object sender, EventArgs e)
        {
            if (cbRequestID.SelectedIndex != -1)
            {
                int reqID = int.Parse(cbRequestID.SelectedItem.ToString());
                Request req = new Request();
                req.UpdatePayment(reqID);
                MessageBox.Show("Update successful");
            }
            else
            {
                MessageBox.Show("Please select the request ID for this payment.");
            }
        }

        private void lblPaymentStatusList_Click(object sender, EventArgs e)
        {

        }

        private void cbChoice_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AcceptPaymentForm_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
