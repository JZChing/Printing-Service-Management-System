﻿namespace IOOP_Assignment1
{
    partial class AcceptPaymentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGenerateReceipt = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnAcceptPayment = new System.Windows.Forms.Button();
            this.lblPaymentStatusList = new System.Windows.Forms.Label();
            this.dgvRequest = new System.Windows.Forms.DataGridView();
            this.cbRequestID = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequest)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGenerateReceipt
            // 
            this.btnGenerateReceipt.Location = new System.Drawing.Point(208, 319);
            this.btnGenerateReceipt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnGenerateReceipt.Name = "btnGenerateReceipt";
            this.btnGenerateReceipt.Size = new System.Drawing.Size(153, 30);
            this.btnGenerateReceipt.TabIndex = 13;
            this.btnGenerateReceipt.Text = "Generate Receipt";
            this.btnGenerateReceipt.UseVisualStyleBackColor = true;
            this.btnGenerateReceipt.Click += new System.EventHandler(this.btnGenerateReceipt_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(550, 319);
            this.btnExit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(78, 30);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnAcceptPayment
            // 
            this.btnAcceptPayment.Location = new System.Drawing.Point(61, 319);
            this.btnAcceptPayment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAcceptPayment.Name = "btnAcceptPayment";
            this.btnAcceptPayment.Size = new System.Drawing.Size(120, 30);
            this.btnAcceptPayment.TabIndex = 11;
            this.btnAcceptPayment.Text = "Accept Payment";
            this.btnAcceptPayment.UseVisualStyleBackColor = true;
            this.btnAcceptPayment.Click += new System.EventHandler(this.btnAcceptPayment_Click);
            // 
            // lblPaymentStatusList
            // 
            this.lblPaymentStatusList.AutoSize = true;
            this.lblPaymentStatusList.Location = new System.Drawing.Point(58, 38);
            this.lblPaymentStatusList.Name = "lblPaymentStatusList";
            this.lblPaymentStatusList.Size = new System.Drawing.Size(128, 16);
            this.lblPaymentStatusList.TabIndex = 10;
            this.lblPaymentStatusList.Text = "Unpaid Request List";
            this.lblPaymentStatusList.Click += new System.EventHandler(this.lblPaymentStatusList_Click);
            // 
            // dgvRequest
            // 
            this.dgvRequest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRequest.Location = new System.Drawing.Point(61, 72);
            this.dgvRequest.Name = "dgvRequest";
            this.dgvRequest.RowHeadersWidth = 51;
            this.dgvRequest.RowTemplate.Height = 24;
            this.dgvRequest.Size = new System.Drawing.Size(567, 163);
            this.dgvRequest.TabIndex = 14;
            // 
            // cbRequestID
            // 
            this.cbRequestID.FormattingEnabled = true;
            this.cbRequestID.Location = new System.Drawing.Point(148, 268);
            this.cbRequestID.Name = "cbRequestID";
            this.cbRequestID.Size = new System.Drawing.Size(121, 24);
            this.cbRequestID.TabIndex = 15;
            this.cbRequestID.SelectedIndexChanged += new System.EventHandler(this.cbChoice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 271);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 16;
            this.label1.Text = "Request ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // AcceptPaymentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 382);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbRequestID);
            this.Controls.Add(this.dgvRequest);
            this.Controls.Add(this.btnGenerateReceipt);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAcceptPayment);
            this.Controls.Add(this.lblPaymentStatusList);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AcceptPaymentForm";
            this.Text = "Accept Payment Form";
            this.Load += new System.EventHandler(this.AcceptPaymentForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequest)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGenerateReceipt;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnAcceptPayment;
        private System.Windows.Forms.Label lblPaymentStatusList;
        private System.Windows.Forms.DataGridView dgvRequest;
        private System.Windows.Forms.ComboBox cbRequestID;
        private System.Windows.Forms.Label label1;
    }
}