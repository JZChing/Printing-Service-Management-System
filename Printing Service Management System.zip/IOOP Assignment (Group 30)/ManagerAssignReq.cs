﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment1
{
    public partial class AssignRequestForm : Form
    {
        public AssignRequestForm()
        { 
            InitializeComponent();
            SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-GFKO02HO;Initial Catalog=IOOPAssignment;Integrated Security=True");
            con.Open(); 
            Request rq = new Request();
            rq.loadNewRequest(dgvNewRequest);
            con.Close();

            int request_id;
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT RequestID FROM Request Where RequestStatus = 'New'", con);
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    request_id = reader.GetInt32(0);
                    cbRequestID.Items.Add(request_id);
                }
            }
            con.Close();

            string WorkerID;
            con.Open();
            SqlCommand cmd2 = new SqlCommand("SELECT UserID FROM MasterUser Where Role = 'Worker'", con);
            using (SqlDataReader reader = cmd2.ExecuteReader())
            {
                while (reader.Read())
                {
                    WorkerID = reader.GetString(0);
                    cbWorker.Items.Add(WorkerID);
                }
            }
            con.Close();
        }

        private void btnAssignRequest_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbRequestID != null && cbWorker != null)
                {
                    Request request = new Request();
                    request.AssignRequest(cbWorker.SelectedItem.ToString(), int.Parse(cbRequestID.SelectedItem.ToString()));
                }
                else
                {
                    MessageBox.Show("Please select the request and worker.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AssignRequestForm_Load(object sender, EventArgs e)
        {

        }
    }
}
