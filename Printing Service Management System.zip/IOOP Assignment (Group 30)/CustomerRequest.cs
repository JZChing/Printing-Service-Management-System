﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using RadioButton = System.Windows.Forms.RadioButton;

namespace IOOP_Assignment1
{
    public partial class RequestForm : Form
    {
        string userID;
        Service service = new Service();
        Request request = new Request();
        bool Urgent = false;
        List<RadioButton> RbList = new List<RadioButton>();


        public RequestForm(string userID)
        {
            
            InitializeComponent();
            this.userID = userID;

            //Making List Of Radio Buttons.Later Used For Retrieving Selected Index
            RbList = new List<RadioButton> { RbService1, RbService2, RbService3, RbService4, RbService5, RbService6 };

        }

        private void Request_Load(object sender, EventArgs e)
        {

        }



        private void btnServiceRequest_Click(object sender, EventArgs e)
        {
            //3Parts To Accepting New Request(Validating User Input,Get Service Info,Saves The Request Info)

            //Part1- To Validate User Entered Integer Quantity

            if(service.ValidationInputQuantity(txtQuantity) == false)
            {
                return;
            }

            int quantity = int.Parse(txtQuantity.Text);

            
            




            //Part2-Get Service Info
            try
            {
                               
                int rowNum = service.RowSelection(RbList);//Get Selected Service Index

                if (rowNum == -1) 
                {
                    return;//No Option Is Selected(MessageBox Messge Is Written In RowSelection Method)
                }

                service.GetDetails(rowNum, RbUrgentYes, quantity, lblTotalCost2); //Retrieves Service Related Data From SQL

                request.InsertNewRequest(service.ID, service.Fees, quantity, RbUrgentYes, userID);//Inserts The New Request Details To Request Table(SQL)




            }
            catch
            {
                MessageBox.Show("Please Select From The Service Options Provided");
            }

        }




        //Below Option Is Given So That The Price Displayed Changes According To User Selection
        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            service.TotalCostDisplay(txtQuantity, RbUrgentYes, lblTotalCost2,RbList);
        }
        private void Rbservice1_CheckedChanged_1(object sender, EventArgs e)
        {
            service.TotalCostDisplay(txtQuantity, RbUrgentYes, lblTotalCost2, RbList);
        }

        private void RbService2_CheckedChanged_1(object sender, EventArgs e)
        {
            service.TotalCostDisplay(txtQuantity, RbUrgentYes, lblTotalCost2, RbList);
        }

        private void RbService3_CheckedChanged_1(object sender, EventArgs e)
        {
            service.TotalCostDisplay(txtQuantity, RbUrgentYes, lblTotalCost2, RbList);
        }

        private void RbService4_CheckedChanged_1(object sender, EventArgs e)
        {
            service.TotalCostDisplay(txtQuantity, RbUrgentYes, lblTotalCost2, RbList);
        }

        private void RbService5_CheckedChanged_1(object sender, EventArgs e)
        {
            service.TotalCostDisplay(txtQuantity, RbUrgentYes, lblTotalCost2, RbList);
        }

        private void RbService6_CheckedChanged_1(object sender, EventArgs e)
        {
            service.TotalCostDisplay(txtQuantity, RbUrgentYes, lblTotalCost2, RbList);
        }

        private void RbUrgentNo_CheckedChanged(object sender, EventArgs e)
        {
            service.TotalCostDisplay(txtQuantity, RbUrgentYes, lblTotalCost2, RbList);
        }

        private void RbUrgentYes_CheckedChanged(object sender, EventArgs e)
        {
            service.TotalCostDisplay(txtQuantity, RbUrgentYes, lblTotalCost2, RbList);
        }

        private void txtQuantity_TextChanged_1(object sender, EventArgs e)
        {
            service.TotalCostDisplay(txtQuantity, RbUrgentYes, lblTotalCost2, RbList);
        }




        private void btnClose_Click(object sender, EventArgs e)
        {
            //Close The Form
            this.Close();
        }



        private void Rbservice1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void RbService2_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void RbService3_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void RbService4_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void RbService5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RbService6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RbUrgentYes_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void serviceBox_Enter(object sender, EventArgs e)
        {

        }
    }

}
