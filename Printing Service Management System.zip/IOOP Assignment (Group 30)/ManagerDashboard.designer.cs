﻿namespace IOOP_Assignment1
{
    partial class ManagerDashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbFunction = new System.Windows.Forms.GroupBox();
            this.btnAssignRequest = new System.Windows.Forms.Button();
            this.btnUpdateProfile = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnAcceptPayment = new System.Windows.Forms.Button();
            this.btnCheckStatus = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.gbFunction.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbFunction
            // 
            this.gbFunction.Controls.Add(this.btnAssignRequest);
            this.gbFunction.Controls.Add(this.btnUpdateProfile);
            this.gbFunction.Controls.Add(this.btnLogout);
            this.gbFunction.Controls.Add(this.btnAcceptPayment);
            this.gbFunction.Controls.Add(this.btnCheckStatus);
            this.gbFunction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbFunction.Location = new System.Drawing.Point(116, 106);
            this.gbFunction.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbFunction.Name = "gbFunction";
            this.gbFunction.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbFunction.Size = new System.Drawing.Size(478, 198);
            this.gbFunction.TabIndex = 1;
            this.gbFunction.TabStop = false;
            this.gbFunction.Text = "Dashboard";
            // 
            // btnAssignRequest
            // 
            this.btnAssignRequest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssignRequest.Location = new System.Drawing.Point(258, 47);
            this.btnAssignRequest.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAssignRequest.Name = "btnAssignRequest";
            this.btnAssignRequest.Size = new System.Drawing.Size(158, 29);
            this.btnAssignRequest.TabIndex = 6;
            this.btnAssignRequest.Text = "Assign Request";
            this.btnAssignRequest.UseVisualStyleBackColor = true;
            this.btnAssignRequest.Click += new System.EventHandler(this.btnAssignRequest_Click_1);
            // 
            // btnUpdateProfile
            // 
            this.btnUpdateProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateProfile.Location = new System.Drawing.Point(258, 100);
            this.btnUpdateProfile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUpdateProfile.Name = "btnUpdateProfile";
            this.btnUpdateProfile.Size = new System.Drawing.Size(158, 29);
            this.btnUpdateProfile.TabIndex = 5;
            this.btnUpdateProfile.Text = "Update Profile";
            this.btnUpdateProfile.UseVisualStyleBackColor = true;
            this.btnUpdateProfile.Click += new System.EventHandler(this.btnUpdateProfile_Click_1);
            // 
            // btnLogout
            // 
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(53, 153);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(158, 29);
            this.btnLogout.TabIndex = 4;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click_1);
            // 
            // btnAcceptPayment
            // 
            this.btnAcceptPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAcceptPayment.Location = new System.Drawing.Point(53, 100);
            this.btnAcceptPayment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAcceptPayment.Name = "btnAcceptPayment";
            this.btnAcceptPayment.Size = new System.Drawing.Size(158, 29);
            this.btnAcceptPayment.TabIndex = 2;
            this.btnAcceptPayment.Text = "Accept Payment";
            this.btnAcceptPayment.UseVisualStyleBackColor = true;
            this.btnAcceptPayment.Click += new System.EventHandler(this.btnAcceptPayment_Click_1);
            // 
            // btnCheckStatus
            // 
            this.btnCheckStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckStatus.Location = new System.Drawing.Point(53, 47);
            this.btnCheckStatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCheckStatus.Name = "btnCheckStatus";
            this.btnCheckStatus.Size = new System.Drawing.Size(158, 29);
            this.btnCheckStatus.TabIndex = 1;
            this.btnCheckStatus.Text = "Check Request Status";
            this.btnCheckStatus.UseVisualStyleBackColor = true;
            this.btnCheckStatus.Click += new System.EventHandler(this.btnCheckStatus_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.Location = new System.Drawing.Point(225, 57);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(239, 31);
            this.lblWelcome.TabIndex = 2;
            this.lblWelcome.Text = "Welcome Manager";
            // 
            // ManagerDashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.gbFunction);
            this.Controls.Add(this.lblWelcome);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ManagerDashboardForm";
            this.Text = "Manager Dashboard Form";
            this.Load += new System.EventHandler(this.ManagerDashboardForm_Load);
            this.gbFunction.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbFunction;
        private System.Windows.Forms.Button btnAssignRequest;
        private System.Windows.Forms.Button btnUpdateProfile;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnAcceptPayment;
        private System.Windows.Forms.Button btnCheckStatus;
        private System.Windows.Forms.Label lblWelcome;
    }
}