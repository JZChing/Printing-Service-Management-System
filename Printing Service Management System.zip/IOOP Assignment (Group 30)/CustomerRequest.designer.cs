﻿namespace IOOP_Assignment1
{
    partial class RequestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.btnServiceRequest = new System.Windows.Forms.Button();
            this.lblTotalCost2 = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.RbUrgentNo = new System.Windows.Forms.RadioButton();
            this.RbUrgentYes = new System.Windows.Forms.RadioButton();
            this.serviceBox = new System.Windows.Forms.GroupBox();
            this.RbService6 = new System.Windows.Forms.RadioButton();
            this.RbService5 = new System.Windows.Forms.RadioButton();
            this.RbService4 = new System.Windows.Forms.RadioButton();
            this.RbService3 = new System.Windows.Forms.RadioButton();
            this.RbService2 = new System.Windows.Forms.RadioButton();
            this.RbService1 = new System.Windows.Forms.RadioButton();
            this.lblFee = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.serviceBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(486, 321);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(173, 66);
            this.btnClose.TabIndex = 27;
            this.btnClose.Text = "Back";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnServiceRequest
            // 
            this.btnServiceRequest.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnServiceRequest.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServiceRequest.Location = new System.Drawing.Point(116, 321);
            this.btnServiceRequest.Name = "btnServiceRequest";
            this.btnServiceRequest.Size = new System.Drawing.Size(173, 66);
            this.btnServiceRequest.TabIndex = 26;
            this.btnServiceRequest.Text = "Submit New Request";
            this.btnServiceRequest.UseVisualStyleBackColor = false;
            this.btnServiceRequest.Click += new System.EventHandler(this.btnServiceRequest_Click);
            // 
            // lblTotalCost2
            // 
            this.lblTotalCost2.AutoSize = true;
            this.lblTotalCost2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalCost2.Location = new System.Drawing.Point(617, 224);
            this.lblTotalCost2.Name = "lblTotalCost2";
            this.lblTotalCost2.Size = new System.Drawing.Size(16, 18);
            this.lblTotalCost2.TabIndex = 24;
            this.lblTotalCost2.Text = "0";
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalCost.Location = new System.Drawing.Point(517, 224);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(77, 18);
            this.lblTotalCost.TabIndex = 25;
            this.lblTotalCost.Text = "Total Cost";
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(620, 192);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(100, 22);
            this.txtQuantity.TabIndex = 23;
            this.txtQuantity.TextChanged += new System.EventHandler(this.txtQuantity_TextChanged_1);
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.Location = new System.Drawing.Point(517, 192);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(62, 18);
            this.lblQuantity.TabIndex = 22;
            this.lblQuantity.Text = "Quantity";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.RbUrgentNo);
            this.groupBox2.Controls.Add(this.RbUrgentYes);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(520, 121);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(216, 50);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Is the service request urgent?";
            // 
            // RbUrgentNo
            // 
            this.RbUrgentNo.AutoSize = true;
            this.RbUrgentNo.Checked = true;
            this.RbUrgentNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbUrgentNo.Location = new System.Drawing.Point(145, 21);
            this.RbUrgentNo.Name = "RbUrgentNo";
            this.RbUrgentNo.Size = new System.Drawing.Size(49, 22);
            this.RbUrgentNo.TabIndex = 4;
            this.RbUrgentNo.TabStop = true;
            this.RbUrgentNo.Text = "No";
            this.RbUrgentNo.UseVisualStyleBackColor = true;
            this.RbUrgentNo.CheckedChanged += new System.EventHandler(this.RbUrgentNo_CheckedChanged);
            // 
            // RbUrgentYes
            // 
            this.RbUrgentYes.AutoSize = true;
            this.RbUrgentYes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbUrgentYes.Location = new System.Drawing.Point(86, 21);
            this.RbUrgentYes.Name = "RbUrgentYes";
            this.RbUrgentYes.Size = new System.Drawing.Size(54, 22);
            this.RbUrgentYes.TabIndex = 4;
            this.RbUrgentYes.TabStop = true;
            this.RbUrgentYes.Text = "Yes";
            this.RbUrgentYes.UseVisualStyleBackColor = true;
            this.RbUrgentYes.CheckedChanged += new System.EventHandler(this.RbUrgentYes_CheckedChanged);
            // 
            // serviceBox
            // 
            this.serviceBox.Controls.Add(this.RbService6);
            this.serviceBox.Controls.Add(this.RbService5);
            this.serviceBox.Controls.Add(this.RbService4);
            this.serviceBox.Controls.Add(this.RbService3);
            this.serviceBox.Controls.Add(this.RbService2);
            this.serviceBox.Controls.Add(this.RbService1);
            this.serviceBox.Controls.Add(this.lblFee);
            this.serviceBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serviceBox.Location = new System.Drawing.Point(65, 64);
            this.serviceBox.Name = "serviceBox";
            this.serviceBox.Size = new System.Drawing.Size(383, 220);
            this.serviceBox.TabIndex = 20;
            this.serviceBox.TabStop = false;
            this.serviceBox.Text = "Services:";
            this.serviceBox.Enter += new System.EventHandler(this.serviceBox_Enter);
            // 
            // RbService6
            // 
            this.RbService6.AutoSize = true;
            this.RbService6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbService6.Location = new System.Drawing.Point(7, 169);
            this.RbService6.Name = "RbService6";
            this.RbService6.Size = new System.Drawing.Size(377, 22);
            this.RbService6.TabIndex = 4;
            this.RbService6.Text = "6. Banner                                         RM 10.00 / banner";
            this.RbService6.UseVisualStyleBackColor = true;
            this.RbService6.CheckedChanged += new System.EventHandler(this.RbService6_CheckedChanged_1);
            // 
            // RbService5
            // 
            this.RbService5.AutoSize = true;
            this.RbService5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbService5.Location = new System.Drawing.Point(7, 141);
            this.RbService5.Name = "RbService5";
            this.RbService5.Size = new System.Drawing.Size(358, 22);
            this.RbService5.TabIndex = 4;
            this.RbService5.TabStop = true;
            this.RbService5.Text = "5. Poster Printing (A0 – A3)              RM 3.00 / page";
            this.RbService5.UseVisualStyleBackColor = true;
            this.RbService5.CheckedChanged += new System.EventHandler(this.RbService5_CheckedChanged_1);
            // 
            // RbService4
            // 
            this.RbService4.AutoSize = true;
            this.RbService4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbService4.Location = new System.Drawing.Point(7, 113);
            this.RbService4.Name = "RbService4";
            this.RbService4.Size = new System.Drawing.Size(367, 22);
            this.RbService4.TabIndex = 4;
            this.RbService4.TabStop = true;
            this.RbService4.Text = "4. Binding – Thick Cover                  RM 15.00 / book";
            this.RbService4.UseVisualStyleBackColor = true;
            this.RbService4.CheckedChanged += new System.EventHandler(this.RbService4_CheckedChanged_1);
            // 
            // RbService3
            // 
            this.RbService3.AutoSize = true;
            this.RbService3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbService3.Location = new System.Drawing.Point(6, 85);
            this.RbService3.Name = "RbService3";
            this.RbService3.Size = new System.Drawing.Size(360, 22);
            this.RbService3.TabIndex = 4;
            this.RbService3.TabStop = true;
            this.RbService3.Text = "3. Binding – Comb Binding               RM 5.00 / book";
            this.RbService3.UseVisualStyleBackColor = true;
            this.RbService3.CheckedChanged += new System.EventHandler(this.RbService3_CheckedChanged_1);
            // 
            // RbService2
            // 
            this.RbService2.AutoSize = true;
            this.RbService2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbService2.Location = new System.Drawing.Point(6, 57);
            this.RbService2.Name = "RbService2";
            this.RbService2.Size = new System.Drawing.Size(356, 22);
            this.RbService2.TabIndex = 4;
            this.RbService2.TabStop = true;
            this.RbService2.Text = "2. Printing A4 – Color                       RM 2.50 / page";
            this.RbService2.UseVisualStyleBackColor = true;
            this.RbService2.CheckedChanged += new System.EventHandler(this.RbService2_CheckedChanged_1);
            // 
            // RbService1
            // 
            this.RbService1.AutoSize = true;
            this.RbService1.Checked = true;
            this.RbService1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbService1.Location = new System.Drawing.Point(6, 29);
            this.RbService1.Name = "RbService1";
            this.RbService1.Size = new System.Drawing.Size(358, 22);
            this.RbService1.TabIndex = 4;
            this.RbService1.TabStop = true;
            this.RbService1.Text = "1. Printing A4 – Black and White      RM 0.80 / page";
            this.RbService1.UseVisualStyleBackColor = true;
            this.RbService1.CheckedChanged += new System.EventHandler(this.Rbservice1_CheckedChanged_1);
            // 
            // lblFee
            // 
            this.lblFee.AutoSize = true;
            this.lblFee.Location = new System.Drawing.Point(262, 0);
            this.lblFee.Name = "lblFee";
            this.lblFee.Size = new System.Drawing.Size(57, 25);
            this.lblFee.TabIndex = 3;
            this.lblFee.Text = "Fee: ";
            // 
            // RequestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnServiceRequest);
            this.Controls.Add(this.lblTotalCost2);
            this.Controls.Add(this.lblTotalCost);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.serviceBox);
            this.Name = "RequestForm";
            this.Text = "Request";
            this.Load += new System.EventHandler(this.Request_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.serviceBox.ResumeLayout(false);
            this.serviceBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnServiceRequest;
        private System.Windows.Forms.Label lblTotalCost2;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton RbUrgentNo;
        private System.Windows.Forms.RadioButton RbUrgentYes;
        private System.Windows.Forms.GroupBox serviceBox;
        private System.Windows.Forms.RadioButton RbService6;
        private System.Windows.Forms.RadioButton RbService5;
        private System.Windows.Forms.RadioButton RbService4;
        private System.Windows.Forms.RadioButton RbService3;
        private System.Windows.Forms.RadioButton RbService2;
        private System.Windows.Forms.RadioButton RbService1;
        private System.Windows.Forms.Label lblFee;
    }
}