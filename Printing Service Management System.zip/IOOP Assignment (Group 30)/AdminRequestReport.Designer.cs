﻿namespace IOOP_Assignment1
{
    partial class AdminRequestReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvRequest = new System.Windows.Forms.DataGridView();
            this.requestBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cbYear = new System.Windows.Forms.ComboBox();
            this.cbMonth = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnGenerateRequest = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblNumOfReq = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblServ0001 = new System.Windows.Forms.Label();
            this.lblServ0002 = new System.Windows.Forms.Label();
            this.lblServ0003 = new System.Windows.Forms.Label();
            this.lblServ0004 = new System.Windows.Forms.Label();
            this.lblServ0005 = new System.Windows.Forms.Label();
            this.lblServ0006 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.requestBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvRequest
            // 
            this.dgvRequest.AllowUserToAddRows = false;
            this.dgvRequest.AllowUserToDeleteRows = false;
            this.dgvRequest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRequest.Location = new System.Drawing.Point(12, 55);
            this.dgvRequest.Name = "dgvRequest";
            this.dgvRequest.ReadOnly = true;
            this.dgvRequest.RowHeadersWidth = 51;
            this.dgvRequest.RowTemplate.Height = 24;
            this.dgvRequest.Size = new System.Drawing.Size(1177, 191);
            this.dgvRequest.TabIndex = 0;
            this.dgvRequest.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRequest_CellContentClick);
            // 
            // requestBindingSource
            // 
            this.requestBindingSource.DataMember = "Request";
            // 
            // cbYear
            // 
            this.cbYear.FormattingEnabled = true;
            this.cbYear.Items.AddRange(new object[] {
            "2022",
            "2023"});
            this.cbYear.Location = new System.Drawing.Point(117, 19);
            this.cbYear.Name = "cbYear";
            this.cbYear.Size = new System.Drawing.Size(121, 24);
            this.cbYear.TabIndex = 1;
            // 
            // cbMonth
            // 
            this.cbMonth.FormattingEnabled = true;
            this.cbMonth.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.cbMonth.Location = new System.Drawing.Point(453, 19);
            this.cbMonth.Name = "cbMonth";
            this.cbMonth.Size = new System.Drawing.Size(121, 24);
            this.cbMonth.TabIndex = 2;
            this.cbMonth.SelectedIndexChanged += new System.EventHandler(this.cbMonth_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Year";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(385, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Month";
            // 
            // btnGenerateRequest
            // 
            this.btnGenerateRequest.Location = new System.Drawing.Point(681, 10);
            this.btnGenerateRequest.Name = "btnGenerateRequest";
            this.btnGenerateRequest.Size = new System.Drawing.Size(212, 33);
            this.btnGenerateRequest.TabIndex = 5;
            this.btnGenerateRequest.Text = "Generate Request Report";
            this.btnGenerateRequest.UseVisualStyleBackColor = true;
            this.btnGenerateRequest.Click += new System.EventHandler(this.btnGenerateRequest_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(942, 10);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(135, 33);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(58, 278);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Summary :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(58, 337);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Number of Request :";
            // 
            // lblNumOfReq
            // 
            this.lblNumOfReq.AutoSize = true;
            this.lblNumOfReq.Location = new System.Drawing.Point(209, 337);
            this.lblNumOfReq.Name = "lblNumOfReq";
            this.lblNumOfReq.Size = new System.Drawing.Size(0, 16);
            this.lblNumOfReq.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(508, 278);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(226, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Total Quantity Of Each Service :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(508, 324);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(183, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "Printing A4 - Black and White :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(508, 361);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "Printing A4 - Color :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(508, 397);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(152, 16);
            this.label8.TabIndex = 13;
            this.label8.Text = "Binding - Comb Binding :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(876, 324);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(140, 16);
            this.label9.TabIndex = 14;
            this.label9.Text = "Binding - Thick Cover :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(876, 361);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(152, 16);
            this.label10.TabIndex = 15;
            this.label10.Text = "Poster Printing (A0 - A3) :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(876, 397);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 16);
            this.label11.TabIndex = 16;
            this.label11.Text = "Banner :";
            // 
            // lblServ0001
            // 
            this.lblServ0001.AutoSize = true;
            this.lblServ0001.Location = new System.Drawing.Point(705, 324);
            this.lblServ0001.Name = "lblServ0001";
            this.lblServ0001.Size = new System.Drawing.Size(0, 16);
            this.lblServ0001.TabIndex = 17;
            // 
            // lblServ0002
            // 
            this.lblServ0002.AutoSize = true;
            this.lblServ0002.Location = new System.Drawing.Point(705, 361);
            this.lblServ0002.Name = "lblServ0002";
            this.lblServ0002.Size = new System.Drawing.Size(0, 16);
            this.lblServ0002.TabIndex = 18;
            // 
            // lblServ0003
            // 
            this.lblServ0003.AutoSize = true;
            this.lblServ0003.Location = new System.Drawing.Point(705, 397);
            this.lblServ0003.Name = "lblServ0003";
            this.lblServ0003.Size = new System.Drawing.Size(0, 16);
            this.lblServ0003.TabIndex = 19;
            // 
            // lblServ0004
            // 
            this.lblServ0004.AutoSize = true;
            this.lblServ0004.Location = new System.Drawing.Point(1052, 324);
            this.lblServ0004.Name = "lblServ0004";
            this.lblServ0004.Size = new System.Drawing.Size(0, 16);
            this.lblServ0004.TabIndex = 20;
            // 
            // lblServ0005
            // 
            this.lblServ0005.AutoSize = true;
            this.lblServ0005.Location = new System.Drawing.Point(1052, 361);
            this.lblServ0005.Name = "lblServ0005";
            this.lblServ0005.Size = new System.Drawing.Size(0, 16);
            this.lblServ0005.TabIndex = 21;
            // 
            // lblServ0006
            // 
            this.lblServ0006.AutoSize = true;
            this.lblServ0006.Location = new System.Drawing.Point(1052, 397);
            this.lblServ0006.Name = "lblServ0006";
            this.lblServ0006.Size = new System.Drawing.Size(0, 16);
            this.lblServ0006.TabIndex = 22;
            // 
            // AdminRequestReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 450);
            this.Controls.Add(this.lblServ0006);
            this.Controls.Add(this.lblServ0005);
            this.Controls.Add(this.lblServ0004);
            this.Controls.Add(this.lblServ0003);
            this.Controls.Add(this.lblServ0002);
            this.Controls.Add(this.lblServ0001);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblNumOfReq);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnGenerateRequest);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbMonth);
            this.Controls.Add(this.cbYear);
            this.Controls.Add(this.dgvRequest);
            this.Name = "AdminRequestReport";
            this.Text = "Request Report form";
            this.Load += new System.EventHandler(this.RequestReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.requestBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvRequest;
        
        private System.Windows.Forms.BindingSource requestBindingSource;
        
        private System.Windows.Forms.ComboBox cbYear;
        private System.Windows.Forms.ComboBox cbMonth;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnGenerateRequest;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblNumOfReq;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblServ0001;
        private System.Windows.Forms.Label lblServ0002;
        private System.Windows.Forms.Label lblServ0003;
        private System.Windows.Forms.Label lblServ0004;
        private System.Windows.Forms.Label lblServ0005;
        private System.Windows.Forms.Label lblServ0006;
    }
}