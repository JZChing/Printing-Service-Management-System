﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace IOOP_Assignment1
{
    public partial class ReceiptForm : Form
    {
        public ReceiptForm(int request_ID)
        {
            InitializeComponent();
            int reqID;
            DateTime reqDate;
            string serviceID;
            string customerID;
            int qty;
            bool urgentReq;
            decimal totalCost;

            Request req = new Request();
            req.loadReceipt(request_ID, out reqID, out reqDate, out serviceID, out customerID, out qty, out urgentReq, out totalCost);
            lblReqID.Text = reqID.ToString();
            lblReqDate.Text = reqDate.ToString();
            lblServID.Text = serviceID.ToString();
            lblCustID.Text = customerID.ToString();
            lblQty.Text = qty.ToString();
            lblUrgentReq.Text = urgentReq.ToString();
            labelTotalCost.Text = totalCost.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ReceiptForm_Load(object sender, EventArgs e)
        {

        }
    }
}
