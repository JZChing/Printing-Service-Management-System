﻿using IOOP_Assignment1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment1
{
    public partial class RequestStatusForm : Form
    {
        public RequestStatusForm()
        {
            InitializeComponent();
            Request request = new Request();
            request.LoadRequestStatus(dgvRequests);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Close this page
            this.Close();
        }

        private void RequestStatusForm_Load(object sender, EventArgs e)
        {
            
            

        }
    }
}
