﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace IOOP_Assignment1
{

    public class Request
    {
        private int _requestID;
        private DateTime _date;
        private string _requestStatus;
        private int _quantity;
        private decimal _totalCost;
        private bool _paymentStatus;
        private string _workerAssigned;
        private bool _urgentRequest;
        private string _serviceID;
        private string _customerID;

        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-GFKO02HO ;Initial Catalog=IOOPAssignment;Integrated Security=True");
        public int RequestID
        {
            get { return _requestID; }
            set { _requestID = value; }
        }
        public DateTime RequestDate
        {
            get { return _date; }
            set { _date = value; }
        }
        public string RequestStatus
        {
            get { return _requestStatus; }
            set { _requestStatus = value; }
        }
        public int Quantity
        {
            get { return _quantity; }
            set { _quantity = value; }
        }
        public decimal TotalCost
        {
            get { return _totalCost; }
            set { _totalCost = value; }
        }
        public bool PaymentStatus
        {
            get { return _paymentStatus; }
            set { _paymentStatus = value; }
        }
        public string WorkerAssigned
        {
            get { return _workerAssigned; }
            set { _workerAssigned = value; }
        }
        public bool UrgentRequest
        {
            get { return _urgentRequest; }
            set { _urgentRequest = value; }
        }
        public string ServiceID
        {
            get { return _serviceID; }
            set { _serviceID = value; }
        }
        public string CustomerID
        {
            get { return _customerID; }
            set { _customerID = value; }
        }

        public Request(int requestID, DateTime date, string requestStatus, int quantity, decimal totalCost, bool paymentStatus, string workerAssigned, bool urgentRequest, string serviceID, string customerID)
        { //constructor
            _requestID = requestID;
            _date = date;
            _requestStatus = requestStatus;
            _quantity = quantity;
            _totalCost = totalCost;
            _paymentStatus = paymentStatus;
            _workerAssigned = workerAssigned;
            _urgentRequest = urgentRequest;
            _serviceID = serviceID;
            _customerID = customerID;
        }

        public Request()
        {
            //constructor
        }
        public Request(int requestID, string requestStatus)
        {
            _requestID = requestID;
            _requestStatus = requestStatus;
        } //constructor

        public Request(decimal totalCost)
        {
            _totalCost = totalCost;
            //constructor
        }
        public void AssignRequest(string workerassigned, int requestid) //manager assign request to worker
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Request SET WorkerAssigned = @WorkerAssigned, RequestStatus = 'Pending' WHERE RequestID = @RequestID", con);

            cmd.Parameters.AddWithValue("@WorkerAssigned", workerassigned);
            cmd.Parameters.AddWithValue("@RequestID", requestid);
            cmd.ExecuteScalar();
            con.Close();
            MessageBox.Show("Worker assigned to request");
        }

        public void loadNewRequest(DataGridView dgvNewReq) //load new request to data grid view to let manager choose which request to be assigned to which worker
        {
            List<Request> requests = new List<Request>();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM [Request] where RequestStatus = 'New'", con);

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Request request = new Request(RequestID, RequestDate, RequestStatus, Quantity, TotalCost, PaymentStatus, WorkerAssigned, UrgentRequest, ServiceID, CustomerID);
                    request.RequestID = reader.GetInt32(0);
                    request.RequestDate = reader.GetDateTime(1);
                    request.RequestStatus = reader.GetString(2);
                    request.Quantity = reader.GetInt32(3);
                    request.TotalCost = reader.GetDecimal(4);
                    request.PaymentStatus = reader.GetBoolean(5);
                    if (!reader.IsDBNull(6))
                    {
                        request.WorkerAssigned = reader.GetString(6);
                    }
                    else
                    {
                        request.WorkerAssigned = null; // or whatever default value you want to assign
                    }
                    request.UrgentRequest = reader.GetBoolean(7);
                    request.ServiceID = reader.GetString(8);
                    request.CustomerID = reader.GetString(9);


                    requests.Add(request);
                }
            }
            con.Close();
            dgvNewReq.AutoGenerateColumns = true;
            dgvNewReq.DataSource = requests;

        }
        public void UpdatePayment(int requestid) //take the selected item from combo box as parameter
        {     //manager accept payment and update the request payment status to true
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Request SET Payment_Status = 1 WHERE RequestID = @RequestID", con);

            cmd.Parameters.AddWithValue("@RequestID", requestid);
            cmd.ExecuteScalar();
            con.Close();
        }

        public void loadReceipt(int cbRequest, out int requestID, out DateTime requestDate, out string serviceID, out string customerID, out int quantity, out Boolean urgentRequest, out decimal totalCost)
        {     //manager press generate receipt after payment this function load the data to display in receipt
            
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT RequestID, RequestDate, ServiceID, CustomerID, Quantity, UrgentRequest, TotalCost FROM [Request] where RequestID = @reqID", con);
            cmd.Parameters.AddWithValue("@reqID", cbRequest); //cbrequest is the request that is making payment at the moment

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (!reader.HasRows) //test if there is data to be read
                {
                    throw new InvalidOperationException("No record found for the specified RequestID.");
                }

                reader.Read();
                requestID = reader.GetInt32(0);
                requestDate = reader.GetDateTime(1);
                serviceID = reader.GetString(2);
                customerID = reader.GetString(3);
                quantity = reader.GetInt32(4);
                urgentRequest = reader.GetBoolean(5);
                totalCost = reader.GetDecimal(6);

            }
            con.Close();
        }
        public void LoadRequestToPay(DataGridView dgvReq) //this method is to load request records that hasnt been paid by customers into data grid view
        { //for manager to see
            List<Request> requests = new List<Request>();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM [Request] where Payment_Status = 0 and (RequestStatus = 'Pending' or RequestStatus = 'Completed') ", con);

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Request request = new Request(RequestID, RequestDate, RequestStatus, Quantity, TotalCost, PaymentStatus, WorkerAssigned, UrgentRequest, ServiceID, CustomerID);
                    request.RequestID = reader.GetInt32(0);
                    request.RequestDate = reader.GetDateTime(1);
                    request.RequestStatus = reader.GetString(2);
                    request.Quantity = reader.GetInt32(3);
                    request.TotalCost = reader.GetDecimal(4);
                    request.PaymentStatus = reader.GetBoolean(5);
                    request.WorkerAssigned = reader.GetString(6);
                    request.UrgentRequest = reader.GetBoolean(7);
                    request.ServiceID = reader.GetString(8);
                    request.CustomerID = reader.GetString(9);



                    requests.Add(request);
                }
            }
            con.Close();
            dgvReq.AutoGenerateColumns = true;

            dgvReq.DataSource = requests;

        }
        public void LoadRequestStatus(DataGridView dgvReq)//method to load all the request for manager to see 
        {
            List<Request> requests = new List<Request>();
            con.Open();
            SqlCommand cmd3 = new SqlCommand("SELECT * FROM Request", con);

            using (SqlDataReader reader = cmd3.ExecuteReader())
            {
                while (reader.Read())
                {
                    Request request = new Request(RequestID, RequestDate, RequestStatus, Quantity, TotalCost, PaymentStatus, WorkerAssigned, UrgentRequest, ServiceID, CustomerID);
                    request.RequestID = reader.GetInt32(0);
                    request.RequestDate = reader.GetDateTime(1);
                    request.RequestStatus = reader.GetString(2);
                    request.Quantity = reader.GetInt32(3);
                    request.TotalCost = reader.GetDecimal(4);
                    request.PaymentStatus = reader.GetBoolean(5);
                    if (!reader.IsDBNull(6))
                    {
                        request.WorkerAssigned = reader.GetString(6);
                    }
                    else
                    {
                        request.WorkerAssigned = null; // or whatever default value you want to assign
                    }
                    request.UrgentRequest = reader.GetBoolean(7);
                    request.ServiceID = reader.GetString(8);
                    request.CustomerID = reader.GetString(9); ;



                    requests.Add(request);
                }
            }
            con.Close();
            dgvReq.AutoGenerateColumns = true;

            dgvReq.DataSource = requests;

        }
        public void LoadWorkerRequest(string userID, DataGridView dgvReq) //method to load request for the assigned worker to see
        {
            List<Request> requests = new List<Request>();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM [Request] where WorkerAssigned = @workerID and RequestStatus = 'Pending'", con);
            cmd.Parameters.AddWithValue("@workerID", userID);
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Request request = new Request(RequestID, RequestDate, RequestStatus, Quantity, TotalCost, PaymentStatus, WorkerAssigned, UrgentRequest, ServiceID, CustomerID);
                    request.RequestID = reader.GetInt32(0);
                    request.RequestDate = reader.GetDateTime(1);
                    request.RequestStatus = reader.GetString(2);
                    request.Quantity = reader.GetInt32(3);
                    request.TotalCost = reader.GetDecimal(4);
                    request.PaymentStatus = reader.GetBoolean(5);
                    request.WorkerAssigned = reader.GetString(6);
                    request.UrgentRequest = reader.GetBoolean(7);
                    request.ServiceID = reader.GetString(8);
                    request.CustomerID = reader.GetString(9);



                    requests.Add(request);
                }
            }
            con.Close();
            dgvReq.AutoGenerateColumns = true;
            dgvReq.DataSource = requests;

        }
        public void GenerateRequestReport(string month, string year, DataGridView dgvRequest) //method for admin to generate and view the monthly request report 
        {
            List<Request> requests = new List<Request>();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM [Request] Where ([RequestDate] >= '1 " + month + " " + year + "') and ([RequestDate] <= '30 " + month + " " + year + "')", con);

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Request request = new Request(RequestID, RequestDate, RequestStatus, Quantity, TotalCost, PaymentStatus, WorkerAssigned, UrgentRequest, ServiceID, CustomerID);
                    request.RequestID = reader.GetInt32(0);
                    request.RequestDate = reader.GetDateTime(1);
                    request.RequestStatus = reader.GetString(2);
                    request.Quantity = reader.GetInt32(3);
                    request.TotalCost = reader.GetDecimal(4);
                    request.PaymentStatus = reader.GetBoolean(5);
                    if (!reader.IsDBNull(6))
                    {
                        request.WorkerAssigned = reader.GetString(6);
                    }
                    else
                    {
                        request.WorkerAssigned = null; // or whatever default value you want to assign
                    }
                    request.UrgentRequest = reader.GetBoolean(7);
                    request.ServiceID = reader.GetString(8);
                    request.CustomerID = reader.GetString(9);



                    requests.Add(request);
                }
            }
            con.Close();
            dgvRequest.AutoGenerateColumns = true;
            dgvRequest.DataSource = requests;
            
        }

        public void LoadRequestSummary(string month, string year, Label NumOfReq, Label Serv0001, Label Serv0002, Label Serv0003, Label Serv0004, Label Serv0005, Label Serv0006)
        {
            con.Open();
            SqlCommand cmd2 = new SqlCommand("select count(RequestID) from Request Where ([RequestDate] >= '1 " + month + " " + year + "') and ([RequestDate] <= '30 " + month + " " + year + "')", con);

            using (SqlDataReader reader = cmd2.ExecuteReader())
            {
                while (reader.Read())
                {
                    int numOfRequests = reader.GetInt32(0);
                    NumOfReq.Text = numOfRequests.ToString();
                }
            }
            con.Close();

            con.Open();
            SqlCommand cmd3 = new SqlCommand("select sum(Quantity) from Request Where ([RequestDate] >= '1 " + month + " " + year + "') and ([RequestDate] <= '30 " + month + " " + year + "') group by ServiceID", con);
            Label[] controlArray = new Label[6] { Serv0001, Serv0002, Serv0003, Serv0004, Serv0005, Serv0006 };
            int index = 0;
            for (index = 0; index < 6; index++)
            {
                controlArray[index].Text ="0";
            }
            
            using (SqlDataReader reader = cmd3.ExecuteReader())
            {
                index = 0;
                while (reader.Read() && index < 6)
                {
                    if (!reader.IsDBNull(0))
                    {
                        int ServQty = reader.GetInt32(0);
                        controlArray[index].Text = ServQty.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Error occured");
                    }

                    index++;
                }
            }
            con.Close();
        }
        public void GenerateTotalIncome(string month, string year, DataGridView dgvPayment, Label lblTotalIncome)
        {  //method for admin to generate monthly income
            con.Open();

            SqlCommand cmd2 = new SqlCommand("SELECT SUM(TotalCost) FROM [Request] Where ([RequestDate] >= '1 " + month + " " + year + "') and ([RequestDate] <= '30 " + month + " " + year + "')", con);
            using (SqlDataReader reader = cmd2.ExecuteReader())
            {
                while (reader.Read())
                {
                    Request request = new Request(TotalCost);
                    request.TotalCost = reader.GetDecimal(0);
                    lblTotalIncome.Text = request.TotalCost.ToString();
                }
            }
            con.Close();
        }
        public void UpdateRequestStatus(int TXTRequestID, string STcomboBox) //method for worker to update request status 
        {
            try

            {
                con.Open();
                Request req = new Request(TXTRequestID, STcomboBox);
                if (!IsValidRequestID(TXTRequestID))
                {
                    MessageBox.Show("Invalid Request ID. Please enter a valid ID.");
                    return; // Exit the method if the ID is invalid
                }
                SqlCommand cmd = new SqlCommand("UPDATE [Request] SET [RequestStatus] = @status where RequestID = @requestid", con);


                cmd.Parameters.AddWithValue("@status", req.RequestStatus);
                cmd.Parameters.AddWithValue("@requestID", req.RequestID);


                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Status of the request updated");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        public bool IsValidRequestID(int ReqID)
        {

            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM [Request] WHERE RequestID = @requestid", con);

            cmd.Parameters.AddWithValue("@requestID", ReqID);


            int count = (int)cmd.ExecuteScalar();

            return count > 0;
        }

        public void GetRequestHistory(string userID, DataGridView RequestHistory)
        {
            try
            {


                //Make A Table With A Specific User's Request Data Only
                con.Open();
                SqlCommand cmdID = new SqlCommand("Select * From Request Where CustomerID = @UserID", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmdID);
                DataTable rh = new DataTable("UserRequestHistory");
                cmdID.Parameters.AddWithValue("@UserID", userID);
                sda.Fill(rh);

                RequestHistory.DataSource = rh;

                con.Close();
            }
            catch
            {
                MessageBox.Show("Sorry, Unable To Access Request History");
            }


        }

        public void InsertNewRequest(string serviceID, decimal fees, int quantity, RadioButton RbUrgentYes, string userID)
        {
            //To Insert User New Request Data To SQL           
            try
            {

                con.Open();

                int paymetStatus = 0;
                int urgentRequest = 0;
                if (RbUrgentYes.Checked)
                {
                    urgentRequest = 1;
                }

                SqlCommand cmdInsert = new SqlCommand("INSERT INTO Request (RequestDate, RequestStatus, Quantity, TotalCost, Payment_Status, UrgentRequest, ServiceID, CustomerID) VALUES (@RequestDate, @RequestStatus, @Quantity, @TotalCost, @PaymentStatus, @UrgentRequest, @ServiceID, @CustomerID)", con);

                cmdInsert.Parameters.AddWithValue("@RequestDate", DateTime.Now.Date);
                cmdInsert.Parameters.AddWithValue("@RequestStatus", "New");
                cmdInsert.Parameters.AddWithValue("@Quantity", quantity);
                cmdInsert.Parameters.AddWithValue("@TotalCost", fees);
                cmdInsert.Parameters.AddWithValue("@PaymentStatus", paymetStatus);
                //Worker Should Be Assigned By Manager
                cmdInsert.Parameters.AddWithValue("@UrgentRequest", urgentRequest);
                cmdInsert.Parameters.AddWithValue("@ServiceID", serviceID);
                cmdInsert.Parameters.AddWithValue("@CustomerID", userID);

                cmdInsert.ExecuteNonQuery();


                con.Close();

                MessageBox.Show("Request For New Service Is Accepted");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);

            }

        }
    }
}
