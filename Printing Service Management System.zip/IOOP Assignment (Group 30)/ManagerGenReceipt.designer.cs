﻿namespace IOOP_Assignment1
{
    partial class ReceiptForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRequestID = new System.Windows.Forms.Label();
            this.lblRequestDate = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.lblUrgentRequest = new System.Windows.Forms.Label();
            this.lblServiceID = new System.Windows.Forms.Label();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.lblReqID = new System.Windows.Forms.Label();
            this.lblServID = new System.Windows.Forms.Label();
            this.lblQty = new System.Windows.Forms.Label();
            this.labelTotalCost = new System.Windows.Forms.Label();
            this.lblReqDate = new System.Windows.Forms.Label();
            this.lblCustID = new System.Windows.Forms.Label();
            this.lblUrgentReq = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblRequestID
            // 
            this.lblRequestID.AutoSize = true;
            this.lblRequestID.Location = new System.Drawing.Point(83, 49);
            this.lblRequestID.Name = "lblRequestID";
            this.lblRequestID.Size = new System.Drawing.Size(74, 16);
            this.lblRequestID.TabIndex = 0;
            this.lblRequestID.Text = "RequestID:";
            this.lblRequestID.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblRequestDate
            // 
            this.lblRequestDate.AutoSize = true;
            this.lblRequestDate.Location = new System.Drawing.Point(346, 49);
            this.lblRequestDate.Name = "lblRequestDate";
            this.lblRequestDate.Size = new System.Drawing.Size(93, 16);
            this.lblRequestDate.TabIndex = 1;
            this.lblRequestDate.Text = "Request Date:";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(83, 158);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(58, 16);
            this.lblQuantity.TabIndex = 2;
            this.lblQuantity.Text = "Quantity:";
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Location = new System.Drawing.Point(83, 216);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(71, 16);
            this.lblTotalCost.TabIndex = 3;
            this.lblTotalCost.Text = "Total Cost:";
            // 
            // lblUrgentRequest
            // 
            this.lblUrgentRequest.AutoSize = true;
            this.lblUrgentRequest.Location = new System.Drawing.Point(346, 158);
            this.lblUrgentRequest.Name = "lblUrgentRequest";
            this.lblUrgentRequest.Size = new System.Drawing.Size(104, 16);
            this.lblUrgentRequest.TabIndex = 4;
            this.lblUrgentRequest.Text = "Urgent Request:";
            // 
            // lblServiceID
            // 
            this.lblServiceID.AutoSize = true;
            this.lblServiceID.Location = new System.Drawing.Point(83, 102);
            this.lblServiceID.Name = "lblServiceID";
            this.lblServiceID.Size = new System.Drawing.Size(69, 16);
            this.lblServiceID.TabIndex = 5;
            this.lblServiceID.Text = "ServiceID:";
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Location = new System.Drawing.Point(346, 102);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(80, 16);
            this.lblCustomerID.TabIndex = 6;
            this.lblCustomerID.Text = "CustomerID:";
            // 
            // lblReqID
            // 
            this.lblReqID.AutoSize = true;
            this.lblReqID.Location = new System.Drawing.Point(216, 49);
            this.lblReqID.Name = "lblReqID";
            this.lblReqID.Size = new System.Drawing.Size(0, 16);
            this.lblReqID.TabIndex = 7;
            // 
            // lblServID
            // 
            this.lblServID.AutoSize = true;
            this.lblServID.Location = new System.Drawing.Point(216, 102);
            this.lblServID.Name = "lblServID";
            this.lblServID.Size = new System.Drawing.Size(0, 16);
            this.lblServID.TabIndex = 8;
            // 
            // lblQty
            // 
            this.lblQty.AutoSize = true;
            this.lblQty.Location = new System.Drawing.Point(216, 158);
            this.lblQty.Name = "lblQty";
            this.lblQty.Size = new System.Drawing.Size(0, 16);
            this.lblQty.TabIndex = 9;
            // 
            // labelTotalCost
            // 
            this.labelTotalCost.AutoSize = true;
            this.labelTotalCost.Location = new System.Drawing.Point(216, 216);
            this.labelTotalCost.Name = "labelTotalCost";
            this.labelTotalCost.Size = new System.Drawing.Size(0, 16);
            this.labelTotalCost.TabIndex = 10;
            // 
            // lblReqDate
            // 
            this.lblReqDate.AutoSize = true;
            this.lblReqDate.Location = new System.Drawing.Point(490, 49);
            this.lblReqDate.Name = "lblReqDate";
            this.lblReqDate.Size = new System.Drawing.Size(0, 16);
            this.lblReqDate.TabIndex = 11;
            // 
            // lblCustID
            // 
            this.lblCustID.AutoSize = true;
            this.lblCustID.Location = new System.Drawing.Point(490, 102);
            this.lblCustID.Name = "lblCustID";
            this.lblCustID.Size = new System.Drawing.Size(0, 16);
            this.lblCustID.TabIndex = 12;
            // 
            // lblUrgentReq
            // 
            this.lblUrgentReq.AutoSize = true;
            this.lblUrgentReq.Location = new System.Drawing.Point(490, 158);
            this.lblUrgentReq.Name = "lblUrgentReq";
            this.lblUrgentReq.Size = new System.Drawing.Size(0, 16);
            this.lblUrgentReq.TabIndex = 13;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(86, 284);
            this.btnExit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(77, 26);
            this.btnExit.TabIndex = 14;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // ReceiptForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblUrgentReq);
            this.Controls.Add(this.lblCustID);
            this.Controls.Add(this.lblReqDate);
            this.Controls.Add(this.labelTotalCost);
            this.Controls.Add(this.lblQty);
            this.Controls.Add(this.lblServID);
            this.Controls.Add(this.lblReqID);
            this.Controls.Add(this.lblCustomerID);
            this.Controls.Add(this.lblServiceID);
            this.Controls.Add(this.lblUrgentRequest);
            this.Controls.Add(this.lblTotalCost);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.lblRequestDate);
            this.Controls.Add(this.lblRequestID);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ReceiptForm";
            this.Text = "Receipt Form";
            this.Load += new System.EventHandler(this.ReceiptForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRequestID;
        private System.Windows.Forms.Label lblRequestDate;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.Label lblUrgentRequest;
        private System.Windows.Forms.Label lblServiceID;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.Label lblReqID;
        private System.Windows.Forms.Label lblServID;
        private System.Windows.Forms.Label lblQty;
        private System.Windows.Forms.Label labelTotalCost;
        private System.Windows.Forms.Label lblReqDate;
        private System.Windows.Forms.Label lblCustID;
        private System.Windows.Forms.Label lblUrgentReq;
        private System.Windows.Forms.Button btnExit;
    }
}