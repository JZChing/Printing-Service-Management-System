﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using System.Xml.Linq;

namespace IOOP_Assignment1
{
    public partial class StatusForm : Form
    {
        public StatusForm(string UID)
        {
            InitializeComponent();
            Request request = new Request();
            request.LoadWorkerRequest(UID,dgvReq);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtRequestID.Text != null && STComboBox.SelectedItem != null)
            {
                int ReqID = Convert.ToInt32(txtRequestID.Text);
                Request rq = new Request();
                rq.UpdateRequestStatus(ReqID, STComboBox.SelectedItem.ToString());
            }
        }
        private void button1_Click(object sender, EventArgs e)
            {
                this.Close();
            }

        private void StatusForm_Load(object sender, EventArgs e)
            {
                
            }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvReq_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void STComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void StatusForm_Load_1(object sender, EventArgs e)
        {

        }
    } 
}
