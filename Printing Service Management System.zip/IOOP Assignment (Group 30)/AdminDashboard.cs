﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment1
{
    public partial class AdminPage : Form
    {
        private string userID;
        private User user = new User();


        public AdminPage(string userID)
        {
            InitializeComponent();
            this.userID = userID;
            user.GetUserData(userID);
            
        }

        private void btnRegNewUser_Click(object sender, EventArgs e)
        {
            RegNewUserForm newUserForm = new RegNewUserForm();
            newUserForm.ShowDialog();
        }

        private void btnRequestReport_Click(object sender, EventArgs e)
        {
            AdminRequestReport rr = new AdminRequestReport();
            rr.ShowDialog();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            LogoutConfirmationForm lcf = new LogoutConfirmationForm();
            lcf.ShowDialog();
        }

        private void btnViewTotalIncome_Click(object sender, EventArgs e)
        {
            
            FormTotalIncome formTotalIncome = new FormTotalIncome();
            formTotalIncome.ShowDialog();
        }

        private void btnViewProfile_Click(object sender, EventArgs e)
        {
            /* use profile form created*/
            ProfileForm pf = new ProfileForm(user, userID);
            pf.ShowDialog();
        }

        private void AdminPage_Load(object sender, EventArgs e)
        {

        }
    }
}
