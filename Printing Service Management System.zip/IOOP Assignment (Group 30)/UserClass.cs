﻿using IOOP_Assignment1;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace IOOP_Assignment1
{
    public class User
    {
        private string _id;
        private string _name;
        private string _password;
        private string _role;
        private string _email;
        private string _contact;

        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-GFKO02HO ;Initial Catalog=IOOPAssignment;Integrated Security=True");
        public User(string id, string name, string password, string role, string email, string contact) //constructor
        { 
            _id = id;
            _name = name;
            _password = password;
            _role = role;
            _email = email;
            _contact = contact;
        }

        public User(string id, string password)  //constructor
        {
            _id = id;
            _password = password;
        }
        public User()  //constructor
        {
       
        }
        public User(string password, string email, string contact)  //constructor
        {
            _password = password;
            _email = email; 
            _contact = contact;
        }
        public string ID
        { 
            get { return _id; } 
            set { _name = value; } 
        }
        public string Name
        { 
            get { return _name; }
            set { _name = value; }
        }
        public string Password
        { 
            get { return _password; }
            set { _password = value; }
        }
        public string Role
        { 
            get { return _role; }
            set { _role = value; }
        }
        public string Email
        { 
            get { return _email; }
            set { _email = value; }
        }
        public string Contact
        { 
            get { return _contact; }
            set { _contact = value; }
        }


        public void RegisterNewUser(string id, string name, string password, string role, string email, string contact)
        {   //method for admin to register a new user into the system
            try
            {
                //create an instance of user
                User newUser = new User(id, name, password, role, email, contact);
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO [MasterUser] ([UserID], [Name], [Password],[Role],[Email],[Contact] ) VALUES (@id, @name, @password, @role, @email, @contact)", con);

                cmd.Parameters.AddWithValue("@id", newUser.ID);
                cmd.Parameters.AddWithValue("@name", newUser.Name);
                cmd.Parameters.AddWithValue("@password", newUser.Password);
                cmd.Parameters.AddWithValue("@role", newUser.Role);
                cmd.Parameters.AddWithValue("@email", newUser.Email);
                cmd.Parameters.AddWithValue("@contact", newUser.Contact);


                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("New User Added");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void UpdateUserData(string newPassword, string newEmail, string newContact, string userID) //method for any role user to update their own profile data
        {
            try
            {
                User newUser = new User(newPassword, newEmail, newContact); //rmb include userid
                con.Open();

                SqlCommand cmdUpdate = new SqlCommand("UPDATE MasterUser SET Password = @UPassword, Email = @UEmail, Contact = @UContact WHERE UserID = @UserID", con);

                cmdUpdate.Parameters.AddWithValue("@UPassword", newUser.Password);
                cmdUpdate.Parameters.AddWithValue("@UEmail", newUser.Email);
                cmdUpdate.Parameters.AddWithValue("@UContact", newUser.Contact);
                cmdUpdate.Parameters.AddWithValue("@UserID", userID);

                cmdUpdate.ExecuteNonQuery();
                MessageBox.Show("User data updated");
                con.Close();
            }
            catch (Exception ex) 
            { 
                MessageBox.Show(ex.Message);
            }

           
        }
        public void login(string userID, string password) //method that that userid and password from user, check with database and login according to role if valid
        {
            con.Open();
            User user = new User(userID, password);
            SqlCommand cmd = new SqlCommand("SELECT Role FROM [MasterUser] Where [UserID] = @UserID and [Password]=@Password", con);
            cmd.Parameters.AddWithValue("@UserID", user.ID);
            cmd.Parameters.AddWithValue("@Password", user.Password);

            string role = null;

            try
            {
                var _role = cmd.ExecuteScalar(); //getting result of role
                if (_role != null)
                {
                    role = _role.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (role != null)
            {
                if (role == "Admin")
                {
                    AdminPage af = new AdminPage(userID);
                    af.ShowDialog();
                }
                else if (role == "Manager")
                {
                   
                    ManagerDashboardForm mf = new ManagerDashboardForm(userID);
                    mf.ShowDialog();
                }
                else if (role == "Worker")
                {
                    WorkerDash wf = new WorkerDash(userID);
                    wf.ShowDialog();
                }
                else if (role == "Customer")
                {                    
                    CustomerForm cf = new CustomerForm(userID);
                    cf.ShowDialog();                                                                                  
                }
            }
            else
            {
                MessageBox.Show("Invalid username or password.");
            }
        }

        public bool ValidateProfileUserInput(bool dataChange, TextBox txtPassword1, TextBox txtPassword2, TextBox txtContact, TextBox txtEmail)
        {
            //Validating User Input For Profile Update
            try
            {
                //Validating User Input Password(Only If Data Is Changed)
                if (dataChange == true)
                {

                    if (txtPassword1.Text.Length < 8)
                    {
                        MessageBox.Show("Password Must Contain Atleast 8 Characters ");
                        txtPassword1.Focus();
                        return false;
                    }
                    if (txtPassword1.Text != txtPassword2.Text)
                    {

                        MessageBox.Show("Passwords Dose Not Match, Please Re-Enter ");
                        txtPassword2.Focus();
                        return false;
                    }
                    else
                    {
                        Password = txtPassword1.Text;//Validated Data Stored
                    }
                }

                Regex emailRegex = new Regex(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$");
                if (!emailRegex.IsMatch(txtEmail.Text))
                {   //to make sure email in correct format
                    MessageBox.Show("Invalid email format");
                    return false;
                }

                Regex contactRegex = new Regex(@"^\d{3}-\d{7}$");
                if (!contactRegex.IsMatch(txtContact.Text))
                {   // to make sure contact in correct format
                    MessageBox.Show("Invalid contact format");
                    return false;
                }
                //Validating User Input Contact
                //Validated Data Stored
                Contact = txtContact.Text;
                Email = txtEmail.Text;
                //Opening Update Confirm Form(For Part 2 And 3)
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
                return false;
            }
        }
        public void GetUserData(string userID)
        {
            //Retreive User Data
            try
            {
                con.Open();
                
                using (SqlCommand cmdID = new SqlCommand("Select * From MasterUser Where UserID = @UserID", con))
                {
                    
                    SqlDataAdapter sda = new SqlDataAdapter(cmdID);
                    DataTable dt = new DataTable("UserInfo");
                    cmdID.Parameters.AddWithValue("@UserID", userID);
                    sda.Fill(dt);//dt DataTable

                    ID = dt.Rows[0].Field<string>("UserID");
                    Name = dt.Rows[0].Field<string>("Name");
                    Email = dt.Rows[0].Field<string>("Email");
                    Contact = dt.Rows[0].Field<string>("Contact");
                    Password = dt.Rows[0].Field<string>("Password");
                    Role = dt.Rows[0].Field<string>("Role");
                    


                }
                con.Close();
            }
            catch
            {
                MessageBox.Show("Error: Unable To Retrieve User Data");

            }
        }




    }
}
