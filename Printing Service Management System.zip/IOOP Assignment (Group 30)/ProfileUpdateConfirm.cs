﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace IOOP_Assignment1
{
    
    public partial class UpdateConfirmForm : Form
    {
        private User user;
        private string user_ID;
        public UpdateConfirmForm(User user, string userID)
        {
            InitializeComponent();
            this.user = user;
            user_ID = userID;
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            user.UpdateUserData(user.Password, user.Email, user.Contact,user_ID);//Update Method
            MessageBox.Show("User Profile Updated Successfully");
            this.Close();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void UpdateConfirmForm_Load(object sender, EventArgs e)
        {

        }
    }
}
