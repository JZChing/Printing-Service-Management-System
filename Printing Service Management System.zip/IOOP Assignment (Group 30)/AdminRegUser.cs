﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace IOOP_Assignment1
{
    public partial class RegNewUserForm : Form
    {
       
        public RegNewUserForm()
        {
            InitializeComponent();
           
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(tbUserID.Text) || string.IsNullOrEmpty(tbUsername.Text) || string.IsNullOrEmpty(tbPW.Text)|| string.IsNullOrEmpty(cbRole.SelectedItem.ToString()) || string.IsNullOrEmpty(tbEmail.Text)|| string.IsNullOrEmpty(tbContact.Text))
                { //to make sure all information of new user are provided
                    MessageBox.Show("All fields are required");
                    return; //return to entering data page for admin to enter new user data
                }

                Regex emailRegex = new Regex(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$");
                if (!emailRegex.IsMatch(tbEmail.Text))
                {   //to make sure email in correct format
                    MessageBox.Show("Invalid email format");
                    return;
                }

                Regex contactRegex = new Regex(@"^\d{3}-\d{7}$");
                if (!contactRegex.IsMatch(tbContact.Text))
                {   // to make sure contact in correct format
                    MessageBox.Show("Invalid contact format");
                    return;
                }

                User user = new User();
                user.RegisterNewUser(tbUserID.Text, tbUsername.Text, tbPW.Text, cbRole.SelectedItem.ToString(), tbEmail.Text, tbContact.Text);
                MessageBox.Show("User added");
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbContact_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void RegNewUserForm_Load(object sender, EventArgs e)
        {

        }
    }
}
