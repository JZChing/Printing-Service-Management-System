﻿namespace IOOP_Assignment1
{
    partial class RequestHistoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.RequestHistoryTable = new System.Windows.Forms.DataGridView();
           
            this.requestBindingSource = new System.Windows.Forms.BindingSource(this.components);
            
            this.requestIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.requestDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.requestStatusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalCostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentStatusDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.workerAssignedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.urgentRequestDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.serviceIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.RequestHistoryTable)).BeginInit();
            
            ((System.ComponentModel.ISupportInitialize)(this.requestBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // RequestHistoryTable
            // 
            this.RequestHistoryTable.AutoGenerateColumns = false;
            this.RequestHistoryTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RequestHistoryTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.requestIDDataGridViewTextBoxColumn,
            this.requestDateDataGridViewTextBoxColumn,
            this.requestStatusDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.totalCostDataGridViewTextBoxColumn,
            this.paymentStatusDataGridViewCheckBoxColumn,
            this.workerAssignedDataGridViewTextBoxColumn,
            this.urgentRequestDataGridViewCheckBoxColumn,
            this.serviceIDDataGridViewTextBoxColumn,
            this.customerIDDataGridViewTextBoxColumn});
            this.RequestHistoryTable.DataSource = this.requestBindingSource;
            this.RequestHistoryTable.Location = new System.Drawing.Point(12, 12);
            this.RequestHistoryTable.Name = "RequestHistoryTable";
            this.RequestHistoryTable.RowHeadersWidth = 51;
            this.RequestHistoryTable.RowTemplate.Height = 24;
            this.RequestHistoryTable.Size = new System.Drawing.Size(1304, 426);
            this.RequestHistoryTable.TabIndex = 0;
            // 
            // assignment_CustomerDataSet3
            // 
            
            
            // 
            // requestBindingSource
            // 
            this.requestBindingSource.DataMember = "Request";
            
            // 
            // requestTableAdapter
            // 
            
            // 
            // requestIDDataGridViewTextBoxColumn
            // 
            this.requestIDDataGridViewTextBoxColumn.DataPropertyName = "RequestID";
            this.requestIDDataGridViewTextBoxColumn.HeaderText = "RequestID";
            this.requestIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.requestIDDataGridViewTextBoxColumn.Name = "requestIDDataGridViewTextBoxColumn";
            this.requestIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.requestIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // requestDateDataGridViewTextBoxColumn
            // 
            this.requestDateDataGridViewTextBoxColumn.DataPropertyName = "RequestDate";
            this.requestDateDataGridViewTextBoxColumn.HeaderText = "RequestDate";
            this.requestDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.requestDateDataGridViewTextBoxColumn.Name = "requestDateDataGridViewTextBoxColumn";
            this.requestDateDataGridViewTextBoxColumn.Width = 125;
            // 
            // requestStatusDataGridViewTextBoxColumn
            // 
            this.requestStatusDataGridViewTextBoxColumn.DataPropertyName = "RequestStatus";
            this.requestStatusDataGridViewTextBoxColumn.HeaderText = "RequestStatus";
            this.requestStatusDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.requestStatusDataGridViewTextBoxColumn.Name = "requestStatusDataGridViewTextBoxColumn";
            this.requestStatusDataGridViewTextBoxColumn.Width = 125;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.Width = 125;
            // 
            // totalCostDataGridViewTextBoxColumn
            // 
            this.totalCostDataGridViewTextBoxColumn.DataPropertyName = "TotalCost";
            this.totalCostDataGridViewTextBoxColumn.HeaderText = "TotalCost";
            this.totalCostDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.totalCostDataGridViewTextBoxColumn.Name = "totalCostDataGridViewTextBoxColumn";
            this.totalCostDataGridViewTextBoxColumn.Width = 125;
            // 
            // paymentStatusDataGridViewCheckBoxColumn
            // 
            this.paymentStatusDataGridViewCheckBoxColumn.DataPropertyName = "Payment_Status";
            this.paymentStatusDataGridViewCheckBoxColumn.HeaderText = "Payment_Status";
            this.paymentStatusDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.paymentStatusDataGridViewCheckBoxColumn.Name = "paymentStatusDataGridViewCheckBoxColumn";
            this.paymentStatusDataGridViewCheckBoxColumn.Width = 125;
            // 
            // workerAssignedDataGridViewTextBoxColumn
            // 
            this.workerAssignedDataGridViewTextBoxColumn.DataPropertyName = "WorkerAssigned";
            this.workerAssignedDataGridViewTextBoxColumn.HeaderText = "WorkerAssigned";
            this.workerAssignedDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.workerAssignedDataGridViewTextBoxColumn.Name = "workerAssignedDataGridViewTextBoxColumn";
            this.workerAssignedDataGridViewTextBoxColumn.Width = 125;
            // 
            // urgentRequestDataGridViewCheckBoxColumn
            // 
            this.urgentRequestDataGridViewCheckBoxColumn.DataPropertyName = "UrgentRequest";
            this.urgentRequestDataGridViewCheckBoxColumn.HeaderText = "UrgentRequest";
            this.urgentRequestDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.urgentRequestDataGridViewCheckBoxColumn.Name = "urgentRequestDataGridViewCheckBoxColumn";
            this.urgentRequestDataGridViewCheckBoxColumn.Width = 125;
            // 
            // serviceIDDataGridViewTextBoxColumn
            // 
            this.serviceIDDataGridViewTextBoxColumn.DataPropertyName = "ServiceID";
            this.serviceIDDataGridViewTextBoxColumn.HeaderText = "ServiceID";
            this.serviceIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.serviceIDDataGridViewTextBoxColumn.Name = "serviceIDDataGridViewTextBoxColumn";
            this.serviceIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            this.customerIDDataGridViewTextBoxColumn.DataPropertyName = "CustomerID";
            this.customerIDDataGridViewTextBoxColumn.HeaderText = "CustomerID";
            this.customerIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            this.customerIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // RequestHistoryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1330, 450);
            this.Controls.Add(this.RequestHistoryTable);
            this.Name = "RequestHistoryForm";
            this.Text = "RequestHistory";
            this.Load += new System.EventHandler(this.RequestHistory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.RequestHistoryTable)).EndInit();
            
            ((System.ComponentModel.ISupportInitialize)(this.requestBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView RequestHistoryTable;
        
        private System.Windows.Forms.BindingSource requestBindingSource;
        
        private System.Windows.Forms.DataGridViewTextBoxColumn requestIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn requestDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn requestStatusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalCostDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn paymentStatusDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerAssignedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn urgentRequestDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
    }
}