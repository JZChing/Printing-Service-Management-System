﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment1
{
    
    public partial class WorkerDash : Form
    {
        private string userID;
        private User user = new User();

        public WorkerDash(string user_id)
        {
            InitializeComponent();
            this.userID = user_id;
            user.GetUserData(userID);
        }

        private void btnChSt_Click(object sender, EventArgs e)
        {
            StatusForm sf = new StatusForm(this.userID);
            sf.ShowDialog();
            
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            LogoutConfirmationForm lcf = new LogoutConfirmationForm();
            lcf.ShowDialog();
        }

        private void btnUpdtPf_Click(object sender, EventArgs e)
        {
            ProfileForm pf = new ProfileForm(user, userID);
            pf.ShowDialog();
        }

        private void WorkerDash_Load(object sender, EventArgs e)
        {

        }
    }
}
