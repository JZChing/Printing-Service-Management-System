﻿namespace IOOP_Assignment1
{
    partial class WorkerDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnChSt = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnUpdtPf = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(227, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(328, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome Worker";
            // 
            // btnChSt
            // 
            this.btnChSt.Location = new System.Drawing.Point(65, 21);
            this.btnChSt.Name = "btnChSt";
            this.btnChSt.Size = new System.Drawing.Size(170, 51);
            this.btnChSt.TabIndex = 1;
            this.btnChSt.Text = "Check and Update Status";
            this.btnChSt.UseVisualStyleBackColor = true;
            this.btnChSt.Click += new System.EventHandler(this.btnChSt_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnLogout);
            this.groupBox1.Controls.Add(this.btnUpdtPf);
            this.groupBox1.Controls.Add(this.btnChSt);
            this.groupBox1.Location = new System.Drawing.Point(235, 159);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(300, 208);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dashboard";
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(65, 135);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(170, 51);
            this.btnLogout.TabIndex = 3;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnUpdtPf
            // 
            this.btnUpdtPf.Location = new System.Drawing.Point(65, 78);
            this.btnUpdtPf.Name = "btnUpdtPf";
            this.btnUpdtPf.Size = new System.Drawing.Size(170, 51);
            this.btnUpdtPf.TabIndex = 2;
            this.btnUpdtPf.Text = "Update Profile";
            this.btnUpdtPf.UseVisualStyleBackColor = true;
            this.btnUpdtPf.Click += new System.EventHandler(this.btnUpdtPf_Click);
            // 
            // WorkerDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "WorkerDash";
            this.Text = "Worker Dashboard";
            this.Load += new System.EventHandler(this.WorkerDash_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnChSt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnUpdtPf;
    }
}