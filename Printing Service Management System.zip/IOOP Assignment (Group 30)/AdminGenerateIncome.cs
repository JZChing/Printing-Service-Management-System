﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace IOOP_Assignment1
{
    public partial class FormTotalIncome : Form
    {
        
        public FormTotalIncome()
        {
            InitializeComponent();
            
        }

        private void FormTotalIncome_Load(object sender, EventArgs e)
        {
            

        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            if (cbMonth.SelectedItem != null && cbYear.SelectedItem != null)
            {
                Request request = new Request();
                request.GenerateRequestReport(cbMonth.SelectedItem.ToString(), cbYear.SelectedItem.ToString(), dgvPayment);
                request.GenerateTotalIncome(cbMonth.SelectedItem.ToString(), cbYear.SelectedItem.ToString(), dgvPayment, lblTotalIncome);
            }
            else
            {
                MessageBox.Show("Please choose the month and year.");
            }
        }

        private void dgvPayment_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
